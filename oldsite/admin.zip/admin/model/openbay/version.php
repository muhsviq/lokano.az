<?php
class ModelOpenbayVersion extends Model {
	public function getVersion() {
		return (int)2334;
	}
}
?>