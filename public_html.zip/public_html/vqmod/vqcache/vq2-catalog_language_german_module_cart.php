<?php
// Heading 
$_['heading_title']        = 'Warenkorb';

// Text
$_['text_items']           = '%s Produkt(e) - %s';
$_['text_empty']           = 'Ihr Warenkorb ist leer!';
$_['text_cart']            = 'Warenkorb';
$_['text_checkout']        = 'Kasse';
 $_['text_latest_added'] = 'Neueste hinzugefugt Produkt (e):';
				$_['text_items2']    = '%s';
				

$_['text_payment_profile'] = 'Zahlungsprofil';
?>