<?php
// Heading 
$_['heading_title'] = 'Latest';

// Text
$_['text_reviews']  = 'Based on %s reviews.'; 
		
				$_['button_details']          = 'Details';
				$_['button_compare']          = 'Add to compare';
				$_['button_wishlist']          = 'Add to wishlist';
				
?>