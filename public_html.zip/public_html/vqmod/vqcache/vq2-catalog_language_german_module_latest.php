<?php
// Heading
$_['heading_title']  = 'Neuigkeiten';

// Text
$_['text_reviews']   = '%s Beurteilungen.';
		
				$_['button_cart']           = 'In den Warenkorb';
				$_['button_details']          = 'Details';
				$_['text_category'] = 'Kategorie:';
				$_['text_manufacturer'] = 'Marke:';
				$_['text_model'] = 'Model:';
				$_['text_availability'] = 'Verfugbarkeit:';
				$_['text_instock'] = 'Vorratig';
				$_['text_outstock'] = 'Heraus ';
				$_['text_price']        = 'Preis: ';
				$_['text_tax']          = 'Preis ohne Steuer:';
				$_['text_quick']          = 'Quick View'; 
				
?>