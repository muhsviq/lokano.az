<?php
// Text
$_['text_information']  = 'Información';
$_['text_service']      = 'Servicio al Cliente';
$_['text_extra']        = 'Extras';
$_['text_contact']      = 'Contáctanos';
$_['text_return']       = 'Devoluciones';
$_['text_sitemap']      = 'Mapa del sitio';
$_['text_manufacturer'] = 'Marcas';
$_['text_voucher']      = 'Vales de regalo';
$_['text_affiliate']    = 'Afiliados';
$_['text_special']      = 'Especiales';
$_['text_account']      = 'Mi cuenta';
$_['text_order']        = 'Historial de pedidos';
$_['text_wishlist']     = 'Lista de deseos';
 
				$_['text_follow']   = 'Siganos';
				$_['text_support']   = 'El soporte en linea';
				$_['text_fb']   = 'Facebook';
				$_['text_twi']   = 'Twitter';
				$_['text_rss']   = 'RSS';
				$_['text_yt']   = 'You Tube';
				
$_['text_newsletter']   = 'Boletín de noticias';
$_['text_powered']      = 'Creado por <a href="http://www.opencart.com">OpenCart</a><br /> %s &copy; %s';
?>
