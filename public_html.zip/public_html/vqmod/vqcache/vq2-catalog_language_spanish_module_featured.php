<?php
// Heading 
$_['heading_title'] = 'Destacados';

// Text
$_['text_reviews']  = 'Basado en %s valoraciones.'; 
		
				$_['button_cart']           = 'Al Carro';
				$_['button_details']          = 'Detalles';
				$_['text_category'] = 'Categoria:';
				$_['text_manufacturer'] = 'Marca:';
				$_['text_model'] = 'Codigo Producto:';
				$_['text_availability'] = 'Disponibilidad:';
				$_['text_instock'] = 'En Existen';
				$_['text_outstock'] = 'Fuera de la';
				$_['text_price']        = 'Precio: ';
				$_['text_tax']          = 'Sin Impuesto:';
				$_['text_quick']          = 'Vista rapida'; 
				$_['text_product']          = 'Producto {current} de {total} ';
				$_['text_sale']          = 'Sale';
				
?>