<?php
// Text
$_['text_information']  = 'Informationen';
$_['text_service']      = 'Kundenservice';
$_['text_extra']        = 'Extras';
$_['text_contact']      = 'Kontakt';
$_['text_return']       = 'Retouren';
$_['text_sitemap']      = 'Übersicht';
$_['text_manufacturer'] = 'Marken';
$_['text_voucher']      = 'Geschenkgutscheine';
$_['text_affiliate']    = 'Partner';
$_['text_special']      = 'Angebote';
$_['text_account']      = 'Mein Konto';
$_['text_order']        = 'Auftragshistorie';
$_['text_wishlist']     = 'Wunschzettel';
 
				$_['text_follow']   = 'Folgen Sie uns';
				$_['text_support']   = 'Online-Unterstutzung';
				$_['text_fb']   = 'Facebook';
				$_['text_twi']   = 'Twitter';
				$_['text_rss']   = 'RSS';
				$_['text_yt']   = 'You Tube';
				
$_['text_newsletter']   = 'Newsletter';
$_['text_powered']      = 'Powered By <a href="http://www.opencart.com">OpenCart</a><br /> %s &copy; %s';
?>