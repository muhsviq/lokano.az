<?php
// Heading 
$_['heading_title'] = 'Shopping Cart';

// Text
$_['text_items']    = '%s item(s) - %s';
$_['text_empty']    = 'Your shopping cart is empty!';
$_['text_cart']     = 'View Cart';
$_['text_checkout'] = 'Checkout';
 $_['text_latest_added'] = 'Latest added product(s):';
			$_['text_items2']    = '%s';
				

$_['text_payment_profile'] = 'Payment Profile';
?>