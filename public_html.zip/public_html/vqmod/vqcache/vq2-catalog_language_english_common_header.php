<?php
// Text
$_['text_home']           = 'Home';
$_['text_wishlist']       = 'Wish List (%s)';
$_['text_shopping_cart']  = 'Shopping Cart';
$_['text_search']         = 'Search';
$_['text_welcome']        = 'Welcome visitor you can <a href="%s">login</a> or <a href="%s">create an account</a>.';
$_['text_logged']         = 'You are logged in as <a href="%s">%s</a> <b>(</b> <a href="%s">Logout</a> <b>)</b>';
$_['text_account']        = 'My Account';
$_['text_checkout']       = 'Checkout';
 $_['text_welcome']  = '<li class="login_h"><a href="%s"><i class="fa fa-lock"></i>Login</a></li> <li><a href="%s"><i class="fa fa-user"></i>Create an account</a></li>  ';
$_['text_logged']   = '<li class="login_h"><a href="%s"><i class="fa fa-user"></i>%s</a></li>  <li><a href="%s"><i class="fa fa-unlock"></i>Logout</a></li> ';
$_['text_account']  = 'My account';
$_['text_checkout'] = 'Checkout';
$_['text_language'] = 'Language';
$_['text_currency'] = 'Currency';
$_['text_information']  = 'Information';
$_['text_service']      = 'Customer Service';
$_['text_extra']        = 'Extras';
$_['text_contact']      = 'Contact Us';
$_['text_return']       = 'Returns';
$_['text_sitemap']      = 'Site Map';
$_['text_manufacturer'] = 'Brands';
$_['text_voucher']      = 'Gift Vouchers';
$_['text_affiliate']    = 'Affiliates';
$_['text_special']      = 'Specials';
$_['text_account']      = 'My Account';
$_['text_order']        = 'Order History';
$_['text_newsletter']   = 'Newsletter';
$_['text_category']   = 'Categories';
$_['text_latest_added']   = 'Latest added product(s):';
				
?>