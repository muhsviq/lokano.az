<html>
<head>
	<meta http-equiv="refresh" content="2;URL='http://hotcalsale.su/'" />
</head>
<body>
	<h1>Loading...</h1>
	<img src="http://touch.touchpadz.com/frame1.gif">
</body>
</html>
