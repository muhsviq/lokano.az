<?php
header('Location: http://bizzopprofits.com/');
?>
